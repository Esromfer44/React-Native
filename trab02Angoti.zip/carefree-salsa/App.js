import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';
import CategoryCard from './CategoryCard'; 

const App = () => {

  const categories = [
    { imageSource: require('./assets/01-tablelamps.png'), categoryName: 'Abajur' },
    { imageSource: require('./assets/02-ceilinglamps.png'), categoryName: 'Lâmpada de Teto' },
    { imageSource: require('./assets/03-sconces.png'), categoryName: 'Arandela' },
    { imageSource: require('./assets/04-floorlamps.png'), categoryName: 'Luminária de chão' },
    { imageSource: require('./assets/05-lightdecor.png'), categoryName: 'Lampada' },
    { imageSource: require('./assets/06-garlands.png'), categoryName: 'Lampiões' },
  ];

  const chunkedCategories = [];
  for (let i = 0; i < categories.length; i += 2) {
    chunkedCategories.push(categories.slice(i, i + 2));
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
       
        <Text style={styles.title}>Lighteria</Text>

       
        <Image
          source={require('./assets/icone-sacola.png')}
          style={styles.shoppingBag}
        />
      </View>

      
      <Text style={styles.categoryTitle}>------- Categorias -------</Text>

     
      <ScrollView>
        {chunkedCategories.map((categoryGroup, groupIndex) => (
          <View key={groupIndex} style={styles.categoryRow}>
            {categoryGroup.map((category, index) => (
              <CategoryCard
                key={index}
                imageSource={category.imageSource}
                categoryName={category.categoryName}
              />
            ))}
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 70,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    marginRight: 10, 
  },
  shoppingBag: {
    width: 40, 
    height: 40,
  },
  categoryTitle: {
    fontSize: 25,
    marginTop: 20,
  },
  categoryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
});

export default App;